# World: Harvest 1
# Reeborg picks up all carrots in a square field of carrots.

# Make Reeborg turn right
def turn_right():
    for count in range(3):
        turn_left()

# Turn Reeborg around 180 degrees
def turn_around():
    turn_left()
    turn_left()

# Move Reeborg to the start of the field
def goto_start():
    turn_left()
    move()
    move()
    turn_right()
    move()

# Pick the next carrot
def pick_next():
    move()
    take()

# Pick a row of carrots
def one_row():
    for count in range(6):
        pick_next()
    move()

# Move Reeborg to the next row
def goto_next_row():
    turn_left()
    if is_facing_north():
        move()
        turn_left()
    else:
        turn_around()
        move()
        turn_right()
       
# Main program
think(0)
goto_start()
for count in range(6):
    one_row()
    goto_next_row()
